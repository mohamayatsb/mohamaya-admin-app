function openPage(pageUrl) {
   window.location.href = pageUrl;
}